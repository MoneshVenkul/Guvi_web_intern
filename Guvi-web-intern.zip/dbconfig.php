<?php
    define('DB_HOST', 'localhost');
    define('DB_USER', 'id9343903_monesh');
    define('DB_PASSWORD', 'Venkul123');
    define('DB_DATABASE', 'id9343903_guvi');
?>