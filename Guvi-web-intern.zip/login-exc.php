<?php
	//Start session
	session_start();
	
	require_once 'dbconfig.php';

	//Connect to mysql server
    $link = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_DATABASE);
    if(!$link) {
        die('Failed to connect to server: ' . mysql_error());
    }
    
    
	function clean($str) {
	    $link = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_DATABASE);
		$str = @trim($str);
		if(get_magic_quotes_gpc()) {
			$str = stripslashes($str);
		}
		return mysqli_real_escape_string($link,$str);
	}
	
	//Sanitize the POST values
	$email = clean($_POST['user_email']);
	$password = clean($_POST['password']);
	
	$qry="SELECT * FROM users WHERE email='$email' AND password='".md5($_POST['password'])."'";
	$result=mysqli_query($link,$qry);
	
	//Check whether the query was successful or not
	if($result) {
		if(mysqli_num_rows($result) == 1) {
			
			//Login Successful
			session_regenerate_id();
			
			$member = mysqli_fetch_assoc($result);
			
			$_SESSION['UID'] = $member['id'];
			$_SESSION['NAME'] = $member['name'];
			$_SESSION['USER_EMAIL'] = $member['email'];			
			$_SESSION['PASSWORD'] = $member['password'];
			$_SESSION['dob'] = $member['dob'];
			$_SESSION['age'] = $member['age'];
			$_SESSION['contact'] = $member['contact'];
			session_write_close();
			echo "Login Successful !";
			exit();
		}else {
			//Login failed
			echo "Login Failed !";
			exit();
		}
	}else {
		die("Query failed");
	}
	
	
?>