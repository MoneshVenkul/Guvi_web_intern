<?php
	
	require_once 'dbconfig.php';

	//Connect to mysql server
    $link = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_DATABASE);
    if(!$link) {
        die('Failed to connect to server: ' . mysql_error());
    }
    
    
	function clean($str) {
	    $link = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_DATABASE);
		$str = @trim($str);
		if(get_magic_quotes_gpc()) {
			$str = stripslashes($str);
		}
		return mysqli_real_escape_string($link,$str);
	}
	
	//Sanitize the POST values
	$name = clean($_POST['name']);
	$email = clean($_POST['user_email']);
	$password = clean($_POST['password']);
	$cpassword = clean($_POST['cpassword']);
	
	 $qry_select="SELECT * FROM users WHERE email='$email'";
    $result_select=mysqli_query($link,$qry_select);
    if(mysqli_num_rows($result_select)>0){
      echo "Duplicate Email";
     exit();	  
    }
    else{
	    //Create INSERT query
	    $qry = "INSERT INTO users(name, email, password) VALUES('$name','$email','".md5($_POST['cpassword'])."')";
	    $result = @mysqli_query($link,$qry);
	    
	    //Check whether the query was successful or not
	    if($result) {
		    echo "registered";
		    exit();
	    }else {
		    die("Something went wrong.\n Our team is working on it at the  moment.\n Please try again after some few minutes.". mysqli_error($link));
	    }
    }
	
?>