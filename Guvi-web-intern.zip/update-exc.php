<?php
	//Start session
	session_start();
	
	require_once 'dbconfig.php';

	//Connect to mysql server
    $link = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_DATABASE);
    if(!$link) {
        die('Failed to connect to server: ' . mysql_error());
    }
    
   
    
	function clean($str) {
	    $link = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_DATABASE);
		$str = @trim($str);
		if(get_magic_quotes_gpc()) {
			$str = stripslashes($str);
		}
		return mysqli_real_escape_string($link,$str);
	}
	
	//Sanitize the POST values
	
	//Sanitize the POST values
	$name = clean($_POST['name']);
	$email = $_SESSION['USER_EMAIL'];
	$update_email=clean($_POST['user_email']);
	$dob = clean($_POST['dob']);
	$age = clean($_POST['age']);
	$contact = clean($_POST['contact']);
	 $qry_select="SELECT * FROM users WHERE email='$email'";
	 
    $result_select=mysqli_query($link,$qry_select);
	
    if(mysqli_num_rows($result_select)>0){
		
		$member = mysqli_fetch_assoc($result_select);
			
		$id = $member['id'];
		$sql = "UPDATE users SET name='$name', email='$update_email',dob='$dob',age='$age',contact='$contact' WHERE id='$id'";
		$result=mysqli_query($link,$sql);
		 
		if($result) {
			
			//Login Successful
			session_regenerate_id();
			
			$_SESSION['UID'] = $id;
			$_SESSION['NAME'] = $name;
			$_SESSION['USER_EMAIL'] =$update_email;	
			$_SESSION['dob'] = $dob;
			$_SESSION['age'] = $age;
			$_SESSION['contact'] = $contact;
				
			
			session_write_close();
			
		    echo "updated";
		    exit();
	    }
    }
    else{
	    echo "Email Does not Exist!";
     exit();
    }
	
?>